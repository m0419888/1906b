package com.usian.utils;

import com.usian.pojo.*;
import lombok.Data;

@Data
public class ItemAll {
    private String itemCat;
    private TbItem item;
    private String itemDesc;
    private String itemParamItem;
}
